from texttable import  Texttable


class Board:
    '''
    This class is the representation of a so called bord
    which is an 8*8 matrix
    '''
    def __init__(self):
        self._board = []
        for i in range(8):
            self._board.append([' ']*8)

    def __str__(self):
        '''
        This function definea how our class will look like
        when printed on the screen..
        '''

        table = Texttable()

        for i in range(8):

            table.add_row(self._board[i])

        return table.draw()

    def __saveFile(self,fileName):
        try:
            file = open(fileName,'w')
            for i in range(8):
                for j in range(8):
                    file.write(str(self._board[i][j])+',')
                file.write('\n')
            file.close()
        except IOError:
            raise ValueError('Error occured while saving the simulation!')
        except EOFError:
            raise ValueError('Error occured while saving the simulation!')

    def saveFile(self,fileName):
             self.__saveFile(fileName)

    def __loadFile(self,fileName):
         try:
              file = open(fileName,'r')
              row = file.readline().strip()
              i = 0
              while row != '':
                  row = row.split(',')
                  for j in range(8):
                     self._board[i][j] = row[j]
                  i += 1
                  row = file.readline()
              file.close()
         except IOError:
             raise ValueError('ERROR 404: file not found X_X')
         except EOFError:
            raise ValueError("ERROR 404: file not found X_X")


    def loadFile(self,fileName):
        self.__loadFile(fileName)

    def coordinateValidity(self,x,y):
        '''
        For a given cell (integers x,y rep row and column nb)
        we check if they can be valid coordinates
        '''
        if x<0:
            return 0
        if y<0:
            return 0
        if x>7:
            return 0
        if y>7:
            return 0
        return 1

    def getNeigh(self,x,y):
        '''
        This function returns a list with the coordinates
        of all the neighboors of a cell
        Input: two integers representing the coordinates
        of a cell
        Output: list with coordinates
        '''

        initialList = [[x-1,y-1],[x-1,y],[x-1,y+1],[x,y-1],[x,y+1],[x+1,y-1],[x+1,y],[x+1,y+1]]
        finalList = []

        for coordinates in initialList:
            if self.coordinateValidity(coordinates[0],coordinates[1]) == 1:
                finalList.append(coordinates)

        return finalList

    def getState(self,x,y):
        '''
        This function check the state of a cell (dead/alive)
        Input: x,y -integers representing the coordinates
        Output: x - if cell is alive, ' ' if cell is dead
        '''
        return  self._board[x][y]

    def getNbLivingNeigh(self,x,y):
        '''
        For a given cell we return the number of living neigh
        Input: x,y -coordinates
        Output: nb - nb of living neigh
        '''
        neigh = self.getNeigh(x,y)
        number = 0
        for element in neigh:
            if self.getState(element[0],element[1]) == 'x':
                number += 1

        return  number

    def subPoopulation(self):
        '''
        Any cell with less than 2 living neigh. dies
        '''
        for i in range(8):
            for j in range(8):
                if self.getNbLivingNeigh(i,j) < 2:
                    self._board[i][j] = ' '

    def overPopulation(self):
        '''
        Any cell with more than 3 living neigh. dies
        '''
        for i in range(8):
            for j in range(8):
                if self.getNbLivingNeigh(i,j) > 3:
                    self._board[i][j] = ' '
    def backToLife(self):
        '''
        Any cell with exactly 3 living neigh. oomes
        back to life
        '''

        for i in range(8):
            for j in range(8):
                if self._board[i][j] == ' ':
                    if self.getNbLivingNeigh(i,j) == 3:
                        self._board[i][j] = 'x'

    def __loadPattern(self,patternName,x,y,n):
        '''
        We open the corresponding pattern file
        and apply the pattern,if possible, to
        the current simulation
        Input:
           o patternName - string representing
           the pattern typt
           o x,y - coordinates representing the
           coordinates of the upper left corner
           of the pattern
           o n - current periodicity
        '''
        try:
            pattern_file = str(patternName)+'.txt'
            file = open(pattern_file,'r')
            if patternName.lower() == 'block' or patternName.lower() == 'tub':
                    '''
                    Periodicity does not count here
                    '''

                    row = file.readline().strip()
                    row = row.split(',')
                    file.close()
                    '''
                    we validate the coordinates
                    '''
                    if self.coordinateValidity(x,y) == 0:
                        raise ValueError('Cannot apply the given pattern')
                    i = 0
                    while(i<len(row)):
                        x1 = x + int(row[i])
                        y1 = y + int(row[i+1])
                        i+=2
                        if self.coordinateValidity(int(x1),int(y1)) == 0:
                            raise ValueError('You cannot apply the given pattern')
                    if self.getState(x,y) == 'x':
                        raise  ValueError('You cannot apply pattern on living cells')
                    i = 0
                    while(i<len(row)):
                        x1 = x + int(row[i])
                        y1 = y + int(row[i+1])
                        i+=2
                        if self.getState(int(x1),int(y1)) == 'x':
                            raise ValueError('You cannot apply the given pattern')

                    self._board[x][y] = 'x'
                    i = 0
                    while(i<len(row)):
                        x1 = x + int(row[i])
                        y1 = y + int(row[i+1])
                        self._board[x1][y1] = 'x'
                        i += 2

        except IOError:
                raise  ValueError("UNEXISTING PATTERN!")
        except EOFError:
                raise  ValueError('File not found')



    def loadPattern(self,patternName,x,y,n):
        self.__loadPattern(patternName,x,y,n)

    def simulateGeneration(self,n = 1):
        '''
        This will generate the next n generations
        '''
        counter = 0
        while counter < n:
            self.subPoopulation()
            self.overPopulation()
            self.backToLife()
            counter += 1