from UI.ui import *

game = Board()
gamePlay = ui_simulation_game()
gamePlay.simulationPlay(game)