from BOARD.board_class.board import *

class ui_simulation_game:
    '''
    Here the game simulation will take place
    '''
    def tablePrint(self):
        br = Board()
        print(br)

    def mainMenu(self):
        print('tick [n]')
        print('save <file name>')
        print('load <file name>')
        print('place <pattern name> <x> <y>')
        print('x - exit simulation')

    def checkStrNb(self,text):
        for letter in text:
            if letter not in '0123456789':
                return 0
        return 1

    def getUserCommand(self):
        command = input('Enter your command:\n >')
        command = command.split(' ')
        return command

    def simulationPlay(self,generation):
        while True:
            try:
                print('Current state of simulation')
                print(generation)
                print('\n')
                self.mainMenu()
                command = self.getUserCommand()
                if len(command) == 0:
                    raise ValueError('Invalid command!')
                elif len(command) == 1:
                    if command[0].lower() == 'x':
                        return 0
                    elif command[0].lower() == 'tick':
                        generation.simulateGeneration()
                    else:
                        raise  ValueError('Invalid command!')
                elif len(command) == 2:
                    if command[0].lower() == 'tick':
                        try:
                            number = int(command[1])
                            if number < 1:
                                raise ValueError('N has to be a positive integer ')
                            generation.simulateGeneration(number)
                        except ValueError:
                            raise ValueError('Optional argument n has to be a positive integer!')
                    elif command[0].lower() == 'save':
                           if '.txt' not in command[1]:
                               raise ValueError('Invalid file format')
                           generation.saveFile(str(command[1]))
                    elif command[0].lower() == 'load':
                           if '.txt' not in command[1]:
                               raise ValueError('Invalid file format')
                           generation.loadFile(str(command[1]))
                elif len(command) == 4:
                    if command[0].lower() == 'place':
                          if self.checkStrNb(command[2]) == 0:
                              raise ValueError('X should be an positive number between 0-7')
                          if self.checkStrNb(command[3]) == 0:
                              raise  ValueError('Y should be a natural nb between 0-7')
                          x = int(command[2])
                          y = int(command[3])
                          if x < 0:
                              raise ValueError('X should be an positive number between 0-7')
                          if x > 7:
                              raise ValueError('X should be an positive number between 0-7')
                          if y < 0:
                              raise ValueError('Y should be an positive number between 0-7')
                          if y > 7:
                              raise ValueError('Y should be an positive number between 0-7')
                          generation.loadPattern(command[1],x,y,0)

                    else:
                        raise ValueError('Invalid Command!')

            except ValueError as er:
                print(er)
